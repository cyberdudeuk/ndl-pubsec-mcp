---
name: Domain accuracy issue
about: Report factually incorrect information in a tool or scope document
title: '[DOMAIN] Issue title'
labels: accuracy
---

## Which domain and tool
<!-- e.g. Energy / energy_explain_scheme -->

## What the tool currently says
<!-- Copy the relevant output or text -->

## What is correct
<!-- Provide the correct information with a source (GOV.UK URL, legislation reference, etc.) -->

## Why this matters
<!-- Who is affected if this is wrong? What decision might they make on the basis of incorrect information? -->

## Additional context
<!-- Anything else relevant -->
