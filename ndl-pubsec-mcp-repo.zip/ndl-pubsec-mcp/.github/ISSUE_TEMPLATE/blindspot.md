---
name: User research blindspot
about: Report a user group, scenario, or need not addressed in the current design
title: '[BLINDSPOT] Issue title'
labels: user-research, blindspot
---

## Which domain(s)

## The gap
<!-- Who is not being served, or what situation is not covered? -->

## Evidence
<!-- Research, lived experience, statistics, or other evidence for this gap -->

## Proposed design response
<!-- If you have one — what should the tool do differently? -->
