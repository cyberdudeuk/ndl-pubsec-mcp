## What this PR does

<!-- Clear description of the change -->

## Why
<!-- The user need or problem this addresses -->

## Domain / tool affected

## Type of change
- [ ] New MCP tool
- [ ] Foundation module
- [ ] Documentation update
- [ ] Accuracy fix
- [ ] Accessibility improvement

## Checklist
- [ ] TypeScript strict mode passes (`npm run typecheck`)
- [ ] Any tool outputs include source citations
- [ ] DEIA requirements considered (reading level, accessibility, advocacy route)
- [ ] No secrets, API keys or personal data committed
- [ ] README or docs updated if needed
- [ ] Tests added or updated

## Testing
<!-- How was this tested? Include MCP Inspector results if applicable -->
